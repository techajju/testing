<?php
/**
 * Danugur Book Appointment
 *
 * Plugin Name: Danugur Book Appointment
 * Plugin URI:  #
 * Description: This Plugin make site book appointment functionality
 * Author:      NetFrux Technologies
 * Author URI:  https://netfrux.com/       
 *
 *  
 */

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Invalid request.' );
}


define( 'MY_PLUGIN_PATH', plugin_dir_path( __FILE__ ) ); 
include( MY_PLUGIN_PATH . 'inc/select_service.php');
include( MY_PLUGIN_PATH . 'inc/enter_postcode.php');
include( MY_PLUGIN_PATH . 'inc/services.php');
include( MY_PLUGIN_PATH . 'inc/payment.php');
include( MY_PLUGIN_PATH . 'inc/payment_init.php');


 

/* add_action( 'wp_head', 'wp_footercallable');
	function wp_footercallable()
	{
		$site_url = get_site_url();
		$payment_init = $site_url. '/wp-content/plugins/danugur-services/inc/payment_init.php';

		?>
		<script>
			jQuery(document).ready(function () {
				jQuery("#stripe_custom_js-js").attr('STRIPE_PUBLISHABLE_KEY', 'pk_live_51IbgI6SEyJO7ICxpchzkfcXntBezxTQJwAqD65SgpMwdOsr7dZpbmyiDuNzf3PDL6RxPHn4kTf3LdLU2F0TMRDsl00uV39coSm');
				jQuery("#stripe_custom_js-js").attr('StripeIni', <?=$payment_init?>);

			}); 
		</script>
	<?php
	} */
 

function my_load_scripts($hook) {

	wp_enqueue_script( 'custom_js', plugins_url( '/js/services.js', __FILE__ ), array() );
	//if(is_page(1862)){// Services page
	//wp_enqueue_script( 'stripe_custom_js', plugins_url( '/js/checkout.js', __FILE__ ), array() );
	//}
	wp_enqueue_script( 'stripe_js', 'https://js.stripe.com/v3/', array() );
	wp_register_style( 'my_css', 	plugins_url( '/css/style.css', 	 __FILE__ ), false );
	wp_enqueue_style ( 'my_css' );

}
add_action('wp_enqueue_scripts', 'my_load_scripts');





