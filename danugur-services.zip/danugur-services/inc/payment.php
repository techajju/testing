<?php

// Include configuration file  
// / require_once MY_PLUGIN_PATH . 'inc/payment_init.php';
 // / include( plugin_dir_path( __DIR__ ) . 'stripe-php/init.php');

?>

<?php


add_shortcode( "StripePay", 'PayWithStripeFormDanguar' );
/* define('STRIPE_API_KEY', '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'); 
define('STRIPE_PUBLISHABLE_KEY', 'pk_live_51IbgI6SEyJO7ICxpchzkfcXntBezxTQJwAqD65SgpMwdOsr7dZpbmyiDuNzf3PDL6RxPHn4kTf3LdLU2F0TMRDsl00uV39coSm'); 
   */
function PayWithStripeFormDanguar($atts,$itemPrice=0, $itemName="", $currency="")
{

    shortcode_atts(array(
        'itemPrice' => $itemPrice,
        'itemName' => $itemName,
        'currency' => $currency
    ), $atts);



    $site_url = get_site_url();
    $STRIPE_PUBLISHABLE_KEY = "pk_live_51IbgI6SEyJO7ICxpchzkfcXntBezxTQJwAqD65SgpMwdOsr7dZpbmyiDuNzf3PDL6RxPHn4kTf3LdLU2F0TMRDsl00uV39coSm";
    $STRIPE_API_KEY = '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';
   
    $code = '';
    $code = '
     
    
    
        ';

return $code;
}