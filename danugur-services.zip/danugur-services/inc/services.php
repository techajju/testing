<?php

function p($param)
{
    echo "<pre>";
    print_r($param);
    echo "</pre>";
}

add_shortcode('DanugurServices', 'danugurServices');

error_reporting(E_ERROR | E_PARSE);
function danugurServices()
{ 
    $site_url = get_site_url();   
    $payment_init = $site_url. '/wp-content/plugins/danugur-services/inc/payment_init.php';

    ?>
    <link rel="stylesheet" href="<?=$site_url?>/wp-content/plugins/woo-product-slider/src/Frontend/assets/css/font-awesome.min.css?ver=2.6.4">
    <?php

$service =  $_GET['service'];
$postal = $_GET['postal'];

/*  if( !isset($service)){
echo "Please select service";
$url =  $site_url.'/index.php/select-service/';
wp_redirect( $url );
exit();

}  */

$term = get_term_by('slug', $service, 'services'); 
$term_id = $term->term_id;
$term_name = $term->name;   


$service_img = get_field('service_image', 'services_'.$term_id); 

//Step I 
$step_i  = get_field( "step_i",'services_'.$term_id ); //group I  
$step_i_repeater =  $step_i['title_and_price_setp_i']; 
//echo '<pre>'; print_r( $step_i['title_and_price_setp_i']); echo "</pre>";

$title_setp_i  = get_field( "title_setp_i",$term_id );  
$short_description_setp_i  = get_field( "short_description_setp_i",$term_id );  
$title_and_price_setp_i  = get_field( "title_and_price_setp_i",$term_id );   //Title and Price Repeater


//Step II
    $step_ii  = get_field( "step_ii",'services_'.$term_id ); //group II   
    $step_ii_repeater =  $step_ii['title_and_price_step_2'];  
    

//Step III
    $step_iii  = get_field( "step_iii",'services_'.$term_id ); //group III   
    $step_iii_repeater =  $step_iii['title_and_price_step_3']; 

    // Here User Do User Login or Registration  //Step iV

//Step IV 
$step_iv  = get_field( "step_iv",'services_'.$term_id ); //group IV 

//Step IV
$step_v  = get_field( "step_v",'services_'.$term_id ); //group V
$step_v_repeater = $step_v['timeing'];
//p($step_iv['timeing']);


$html = '';

$html .= '
<div class="container-fluid" id="service_forms">
<div class="row justify-content-center">
<div class="col-11 col-sm-10 col-md-10 col-lg-6 col-xl-5 text-center p-0 mt-3 mb-2">
    <div class="card px-0 pt-4 pb-0 mt-3 mb-3">   
        <form id="msform"  class="hidden" method="post" action="">
            <!-- progressbar -->
            <ul id="progressbar">
                <li class="active" id="account"><strong> Service details </strong></li>
                <li id="personal"><strong> Prices & schedule </strong></li>
                <li id="payment"><strong> Contact details </strong></li>
                <li id="payment"><strong> Time </strong></li>
                <li id="confirm"><strong> User Login </strong></li>
                <li id="persons"><strong> Choose Persons </strong></li>
                <li id="complete"><strong> Payment </strong></li>
            </ul>
            <div class="progress">
                <div class="progress-bar progress-bar-striped progress-bar-animated" role="progressbar" aria-valuemin="0" aria-valuemax="100"></div>
            </div> <br> <!-- fieldsets -->
            <div class="page_wapper">
                <div class="page_col">

                <!-- step 1 --> 
                <fieldset>
                    <div class="form-card">
                        <div class="row">
                            <div class="col-7">
                                    <h2>'.$step_i['title_setp_i'].'</h2> 
                                    <p>'.$step_i['short_description_setp_i'].'<p>
                            </div>
                                
                        </div> 
                        <div class="step_i step">
                        
                        ';
  
                            $s_n_v = 0;
                                    foreach ($step_i_repeater as $setp_i_r_val) {
                                        ++$s_n_v;
                                        $val = $setp_i_r_val['group_step_1']['price_g_setp_i_price']; 
                                        $html .= '<div class="step_i_c_left">
                                                    <input  class="user_change"  type="checkbox" data-name="checkbox_'.$s_n_v.'" id="checkbox_'.$s_n_v.'" name="val_s_i[]" value="'.$setp_i_r_val['group_step_1']['price_g_setp_i_price'].'">
                                                    <span class="  check_span_'.$s_n_v.'">'.$setp_i_r_val['group_step_1']['title_g_setp_i_title'].'</span>       
                                                    <input class="check_'.$s_n_v.'" type="hidden" name="checkbox_val_s_i[]" ><br>
                                                </div>
                                        
                                            <script> 
                                            jQuery( document ).ready(function($) {
                                                jQuery(".next").prop("disabled", true);

                                                var text = jQuery(".check_span_'.$s_n_v.'").text();
                                                    jQuery("#checkbox_'.$s_n_v.'").change(function() { 
                                                    //  console.log(this.checked); 
                                                    if(this.checked == true){
                                                            jQuery(".next").prop("disabled", false);
                                                            jQuery(".check_'.$s_n_v.'").val(text); 
                                                    }else{ 
                                                        jQuery(".check_'.$s_n_v.'").val("");
                                                    }
                                                });   
                                            });
                                                
                                            </script>';
                                        
                                    }

                    $html .='</div>  
                    </div>
                        <input type="button" name="next" class="next action-button" value="Next" />
                </fieldset>
                <!-- end step 1 --> 

                <!-- step 2 --> 

                <fieldset>
                    <div class="form-card">
                        <div class="row">
                        <div class="step_ii step">
                            <div class="col-7">';
                                    
                            if( $step_ii['choose_which_fields_show'] == 'title_price'){ 
                                $html .= '<h2>'.$step_ii['title_step_2'].'</h2>   
                                    <p>'.$step_ii['short_description_step_2'].'<p>';

                                    $s_ii_n_v = 0;
                                    foreach ($step_ii_repeater as $setp_ii_r_val) { 
                                        ++$s_ii_n_v; 
                                        //$val = $setp_ii_r_val['group_step_2']['price_g_step_2']; 
                                    $html .= ' 
                                    <div class="step_i_c_left">
                                        <input class="user_change"   type="checkbox" id="checkbox2_'.$s_ii_n_v.'" data-name="checkbox2_'.$s_ii_n_v.'" name="val_step[]" value="'.$setp_ii_r_val['group_step_2']['title_g_step_2'].'">
                                        <span class="check_span2_'.$s_ii_n_v.'" >'.$setp_ii_r_val['group_step_2']['title_g_step_2'].'</span>
                                        <input class="check2_'.$s_ii_n_v.'" type="hidden" name="checkbox_val_s_ii[]" ><br> 
                                    </div>
                                    
                                    <script> 
                                            jQuery( document ).ready(function($) {
                                                jQuery(".next").prop("disabled", true); 
                                                 var text2 = jQuery(".check_span2_'.$s_ii_n_v.'").text();
                                                        jQuery("#checkbox2_'.$s_ii_n_v.'").change(function() { 
                                                    //  console.log(this.checked);  
                                                    if(this.checked == true){
                                                            jQuery(".next").prop("disabled", false);
                                                            jQuery(".check2_'.$s_ii_n_v.'").val(text2); 
                                                    }else{ 
                                                        jQuery(".check2_'.$s_ii_n_v.'").val("");
                                                    }
                                                });   
                                            }); 
                                            </script>
                                    
                                    
                                    ';
                                }// endif


                                } else{
                                $ggroup =  $step_ii['gender_group'];
                                $g_tilte =  $ggroup['gender_t_title'];
                                $g_description =   $ggroup['gender_t_description'];

                                $html .= '<h2>'.$g_tilte.'</h2>   
                                <p>'.$g_description.'<p>
                                <div> 
                                    <div class="step_i_c_left">
                                        <input type="radio" id="male" name="gender" value="Male">
                                        <label for="html">Male</label><br>
                                            </div> 
                                            <div class="step_i_c_left">
                                        <input type="radio" id="female" name="gender" value="Female">
                                        <label for="css">Female</label>
                                        </div>
                                </div>  ';

                                
                            
                                }
                            
                                    $html .='</div>
                                
                        </div>'; 
                

                    $html .=' </div>  
                    </div>
                        <input type="button" name="next" class="next action-button" value="Next" />
                        <input type="button" name="previous" class="previous action-button-previous" value="Previous" />
                </fieldset>

                <!-- end step 2 -->

                <!-- step 3a -->
                <fieldset>
                    <div class="form-card">
                        <div class="row">
                            <div class="col-7">
                            <h2>'.$step_iii['title_step_3'].'</h2> 
                            <p>'.$step_iii['short_description_step_3'].'<p>
                            </div> 
                        </div> 
                            <div class="step_iii step">'; 
                                        $s_iii_n_v = 0;
                                        foreach ($step_iii_repeater as $setp_iii_r_val) {
                                            ++$s_iii_n_v;
                                            $val = $setp_iii_r_val['group_step_3']['price_g_step_3']; 
                                            $html .= '<div class="step_i_c_left">
                                                            <input class="user_change" type="checkbox" data-name="checkbox3_'.$s_iii_n_v.'"  id="checkbox3_'.$s_iii_n_v.'" name="val_step3'.$s_iii_n_v.'" value="'.$val.'">
                                                            <span  class="check_span3_'.$s_iii_n_v.'" >'.$setp_iii_r_val['group_step_3']['title_g_step_3'].'</span>
                                                            <input class="check3_'.$s_iii_n_v.'" type="hidden" name="checkbox_val_s_iii[]" ><br> 
                                                        </div> 

                                                        <script> 
                                                            jQuery( document ).ready(function($) { 
                                                                jQuery(".next").prop("disabled", true); 
                                                                var text3 = jQuery(".check_span3_'.$s_iii_n_v.'").text();
                                                                        jQuery("#checkbox3_'.$s_iii_n_v.'").change(function() { 
                                                                    //  console.log(this.checked);  
                                                                    if(this.checked == true){
                                                                            jQuery(".next").prop("disabled", false);
                                                                            jQuery(".check3_'.$s_iii_n_v.'").val(text3); 
                                                                    }else{ 
                                                                        jQuery(".check3_'.$s_iii_n_v.'").val("");
                                                                    }
                                                                });   
                                                            }); 
                                                        </script>';
                                        }      
                    $html .=' </div>  
                    </div>
                        <input type="button" name="next" class="next action-button" value="Next" />
                        <input type="button" name="previous" class="previous action-button-previous" value="Previous" />
                </fieldset>
                <!-- end step 3a (Step V) -->

                <!-- step 3b -->
                <fieldset>
                <div class="form-card">
                    <div class="row">
                        <div class="col-7">
                            <h2 class="fs-title">Select Date and Time:</h2>
                        </div> 
                    </div>'; 

                        if(isset($step_v_repeater)){
                                $t = 0;            
                            foreach ($step_v_repeater  as $step_v_repeater_val) {
                                ++$t;
                                $html .= '
                                    <input class="user_change" data-name="step_v_repeater_val_price_'.$t.'" type="radio" id="step_v_repeater_val_'.$t.'" name="step_v_repeater_val" value="'.$step_v_repeater_val['price_step_v'].'">
                                    <input  type="hidden" id="step_v_repeater_val_price" name="step_v_repeater_val_time" value="'.$step_v_repeater_val['time'].'">
                                    <label for="step_v_repeater_val_'.$t.'" class="step_v_repeater_val">
                                        <p>         
                                            <span class="time">'.$step_v_repeater_val['time'].'</span>
                                            <span class="t_price">£'.$step_v_repeater_val['price_step_v'].'</span>

                                        </p>
                                    </label> '; 

                            }     
                            
                        }                


                $html .='</div> 
                <input type="button" name="next" class="next action-button" value="Next" />
            </fieldset>
            <!-- end step 3b --> 

                <!-- step 4 -->
                <fieldset>
                    <div class="form-card">
                        <div class="row">
                            <div class="col-7"> 
                            </div> 
                        </div> 
                        <div class="row justify-content-center">
                            <div class="col-7 text-center">';

                            if(is_user_logged_in() ){
                            
                                $user_id = get_current_user_id();
                                
                                $user_userdata = get_userdata($user_id);
                                $user_info = get_user_meta($user_id);
                                
                                    // p($user_info);

                                    $user_f_name = $user_info['first_name'][0];
                                    if($user_f_name != ''){ $readonly_uf_name = "readonly" ; }

                                    $user_l_name = $user_info['last_name'][0];
                                    if($user_l_name != ''){ $readonly_ul_name = "readonly" ; }

                                    $billing_city = $user_info['billing_city'][0];
                                    if($billing_city != ''){ $readonly_u_city_name = "readonly" ; }
                                    
                                    $billing_country = $user_info['billing_country'][0]; 
                                    if($billing_country != ''){ $readonly_u_country = "readonly" ; }   

                                    $billing_email = $user_info['billing_email'][0];
                                    if($billing_email != ''){ $readonly_u_email = "readonly" ; }   

                                    $billing_phone = $user_info['billing_phone'][0];
                                    if($billing_phone != ''){ $readonly_u_phone = "readonly" ; }   

                                    $billing_postcode = $user_info['billing_postcode'][0];
                                    if($billing_postcode != ''){ $readonly_u_postal = "readonly" ; }   

                                    $html .= 
                                    '   
                                    <div> <h2>Customer billing address</h2></div>

                                    <label for="country">First name:</label>  
                                        <input type="text" id="first_name" name="first_name" value="'.$user_f_name.'" '.$readonly_uf_name.'  ><br>
                                        <label for="country">Last name:</label>  
                                        <input type="text" id="last_name" name="last_name" value="'.$user_l_name.'" '.$readonly_ul_name.'><br>
                                        <label for="country">City:</label>  
                                        <input type="text" id="billing_city" name="billing_city" value="'.$billing_city.'" '. $readonly_u_city_name.'><br>
                                        <label for="country">Country:</label>  
                                        <input type="text" id="billing_country" name="billing_country" value="'.$billing_country.'" '.$readonly_u_country.'><br>
                                        <label for="country">Email:</label>  
                                        <input type="email" id="billing_email" name="billing_email" value="'.$billing_email.'" '.$readonly_u_email.'><br>
                                        <label for="country">Phone:</label>  
                                        <input type="text" id="billing_phone" name="billing_phone" value="'.$billing_phone.'" '.$readonly_u_phone.'><br>
                                        <label for="country">Zip Code:</label>  
                                        <input type="text" id="billing_postcode" name="billing_postcode" value="'.$billing_postcode.'"  '.$readonly_u_postal.' ><br> 
                                            ';

                            }else{

                                $html .= "<h2> User Login and Registration</h2>"; 
                                    $html .= ' 
                                    <button class="lrm-login hide-if-logged-in btn-service">Login</button> 
                                    <button class="register btn-service"><a  target="_blank" href="'.$site_url.'/index.php/register/">Register</a></button>
                                '; 
                            }   
                            $html .='</div>
                        </div>
                    </div> 
                    <input type="button" name="next" class="next action-button" value="Next" />
                        <input type="button" name="previous" class="previous action-button-previous" value="Previous" />
            
                    </fieldset> 
                <!-- end step 4 --> 
                <!-- step 5 --> 
                        <fieldset>
                        <div class="form-card">
                            <div class="row">
                                <div class="col-7">
                                <h2>'.$step_iv['title_step_4'].'</h2> 
                                <p>'.$step_iv['short_description_step_4'].'</p> 
                                    </div> 
                            </div> 
                                <div class="step_v step">'; 
                                    // Persons 
                                    $persons = $step_iv['service_persons']; 
                                    $p =0;
                                foreach ($persons as  $persons) {
                                    $p++;
                                    //  p($persons->term_id);
                                    $person_id = $persons->term_id;
                                    $persons_image  = get_field( "person_image",'service_person_'.$person_id );  
                                    $persons_gender  = get_field( "gender",'service_person_'.$person_id );    
                                    $persons_rating  = get_field( "rating",'service_person_'.$person_id );    
                                    
                                    $person_name = $persons->name; 
                                    
                                    $html .= '<div class="radio-with-Icon">
                                                    <p class="radioOption-Item"> 
                                                    <input type="radio" name="service_person" id="person_'.$p.'" value="'.$person_name.'" class="persons_type">
                                                        <label for="person_'.$p.'"> 
                                                            <img class="persons_img" src="'.$persons_image['url'].'" alt="'.$persons_image['title'].'">
                                                               <input type="hidden" class="persons_image" "name="persons_image" value="'.$persons_image['ID'].'">
                                                            <span class="rating">'.$persons_rating.'</span><br>
                                                               <input type="hidden" class="persons_rating" name="persons_rating" value="'.$persons_rating.'">
                                                            <span class="gender_name"> '.$persons_gender.' </span> 
                                                                <input type="hidden" class="persons_gender" name="persons_gender" value="'.$persons_gender.'">
                                                        </label> 
                                                    </p>
                                                </div>';

                                } 
                                
                        $html .=' </div>  
                        </div>
                        <input type="button" name="next" class="next action-button" value="Next" />
                        <input type="button" name="previous" class="previous action-button-previous" value="Previous" />
                    </fieldset> 
              
                             <!-- end step 5 --> 
                <!--  step 6 -->
                <fieldset>
                    <div class="form-card">
                        <div class="row">
                            <div class="col-7">
                                <h2 class="fs-title">Finish:</h2>
                            </div> 
                        </div>
                            
                        <div class="row justify-content-center">
                            <div class="col-7 text-center">
                            <!-- payment -->

                            <div class="panel">
                            <div class="panel-heading">
                                <h3 class="panel-title">Charge $'.$itemPrice.' with Stripe</h3>
                                
                                <!-- Product Info -->
                                <p><b>Service Name:</b> '. $itemName.'</p>
                                <p><b>Price:</b> '. '$'.$itemPrice.' '.$currency.'</p>
                            </div>
                            <div class="panel-body">
                                <!-- Display status message -->
                                <div id="paymentResponse" class="hidden"></div>
                                 
                                    <div class="form-group">
                                        <label>NAME</label>
                                        <input type="text" id="name" class="field" placeholder="Enter name" required="" autofocus="">
                                    </div>
                                    <div class="form-group">
                                        <label>EMAIL</label>
                                        <input type="email" id="email" class="field" placeholder="Enter email" required="">
                                    </div>
                                    
                                    <div id="paymentElement">
                                        <!--Stripe.js injects the Payment Element-->
                                    </div>
                                    
                                     
                                <!-- Display processing notification -->
                                <div id="frmProcess" class="hidden">
                                    <span class="ring"></span> Processing...
                                </div>
                                 
                            </div>
                        </div>
                    

                            <!-- end payment -->
                            ';
                                 
                            $html .='</div>
                        </div> 
                            <!-- Form submit button -->
                                    <button id="submitBtn" class="btn btn-success">
                                        <div class="spinner hidden" id="spinner"></div>
                                        <span id="buttonText">Pay Now</span>
                                    </button>
                    </div>
                </fieldset>
                <!-- end step 6 --> 
                </div>
                <div class="page_col2">
                    <div class="service_img">
                        <img src="'.$service_img.'" alt="">
                        <h4>'.$term_name .'</h4> 
                        <span class="spanText"></span>
                    </div>
                    <div class="side_col2">';

                    $toggle_r = get_field('toggle_content_r', 'services_'.$term_id );
                        $i = 0;
                        $j= 0; 
                    foreach ($toggle_r as $toggle_c) { 
                        ++$i;
                        ++$j; 
                            $html .= '
                            <a id="display_'.$i.'" href="javascript:toggle('.$j.');">'.$toggle_c['toggle_content']['title'].'</a>
                        <br />
                        <div id="toggle_'.$j.'" style="display: none">'.$toggle_c['toggle_content']['description'].'</div>
                        
                        <script>
                        function toggle(id) {
                            a = document.getElementById("toggle_"+id);
                            b = document.getElementById("display_"+id);
                                if (a.style.display=="block") {
                                a.style.display="none";
                                } else {
                                a.style.display="block";
                                }
                            }
                        </script> ';   
                    }     

                    $html .= '</div>  
                </div>
            </div>
        </form>
    </div>
</div> 
</div>
</div>

<script>

jQuery(document).ready(function ($) {
    jQuery("form").submit(function (event) {
        event.preventDefault();   
        var $form = $("#msform"),
        url = $form.attr( "action" );
        var posting = $.post( url, $form.serialize() );
        posting.done(function( dte ) {
        console.log(dte);
        });
    });
  });


</script> 






<script>
// Get API Key
 let STRIPE_PUBLISHABLE_KEY = "pk_live_51IbgI6SEyJO7ICxpchzkfcXntBezxTQJwAqD65SgpMwdOsr7dZpbmyiDuNzf3PDL6RxPHn4kTf3LdLU2F0TMRDsl00uV39coSm";
   // Create an instance of the Stripe object and set your publishable API key
const stripe = Stripe(STRIPE_PUBLISHABLE_KEY);
 
// Define card elements
let elements;

// Select payment form element
const msform = document.querySelector("#msform");

// Get payment_intent_client_secret param from URL
const clientSecretParam = new URLSearchParams(window.location.search).get(
    "payment_intent_client_secret"
);

// Check whether the payment_intent_client_secret is already exist in the URL
setProcessing(true);
if(!clientSecretParam){
    setProcessing(false);
    
    // Create an instance of the Elements UI library and attach the client secret
    initialize();
}

// Check the PaymentIntent creation status
checkStatus();

// Attach an event handler to payment form
msform.addEventListener("submit", handleSubmit);

// Fetch a payment intent and capture the client secret
let payment_intent_id;
async function initialize() {
    const { id, clientSecret } = await fetch("'.$payment_init.'", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ request_type:"create_payment_intent" }),
    }).then((r) => r.json());
    
    const appearance = {
        theme: "stripe",
        rules: {
            ".Label": {
                fontWeight: "bold",
                textTransform: "uppercase",
            }
        }
    };
    
    elements = stripe.elements({ clientSecret, appearance });
    
    const paymentElement = elements.create("payment");
    paymentElement.mount("#paymentElement");
    
    payment_intent_id = id;
}

// Card form submit handler
async function handleSubmit(e) {
    e.preventDefault();
    setLoading(true);
    
    let customer_name = document.getElementById("name").value;
    let customer_email = document.getElementById("email").value;
    
    const { id, customer_id } = await fetch("'.$payment_init.'", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ request_type:"create_customer", payment_intent_id: payment_intent_id, name: customer_name, email: customer_email }),
    }).then((r) => r.json());
    
    const { error } = await stripe.confirmPayment({
        elements,
        confirmParams: {
            // Make sure to change this to your payment completion page
            return_url: window.location.href+"?customer_id="+customer_id,
        },
    });
    
    // This point will only be reached if there is an immediate error when
    // confirming the payment. Otherwise, your customer will be redirected to
    // your `return_url`. For some payment methods like iDEAL, your customer will
    // be redirected to an intermediate site first to authorize the payment, then
    // redirected to the `return_url`.
    if (error.type === "card_error" || error.type === "validation_error") {
        showMessage(error.message);
    } else {
        showMessage("An unexpected error occured.");
    }
    
    setLoading(false);
}

// Fetch the PaymentIntent status after payment submission
async function checkStatus() {
    const clientSecret = new URLSearchParams(window.location.search).get(
        "payment_intent_client_secret"
    );
    
    const customerID = new URLSearchParams(window.location.search).get(
        "customer_id"
    );
    
    if (!clientSecret) {
        return;
    }
    
    const { paymentIntent } = await stripe.retrievePaymentIntent(clientSecret);
    
    if (paymentIntent) {
        switch (paymentIntent.status) { 
            case "succeeded":
                // Post the transaction info to the server-side script and redirect to the payment status page
                fetch("payment_init.php", {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({ request_type:"payment_insert", payment_intent: paymentIntent, customer_id: customerID }),
                })
                .then(response => response.json())
                .then(data => {
                    if (data.payment_txn_id) {
                        window.location.href = "payment-status.php?pid="+data.payment_txn_id;
                    } else {
                        showMessage(data.error);
                        setReinit();
                    }
                })
                .catch(console.error);
                
                break;
            case "processing":
                showMessage("Your payment is processing.");
                setReinit();
                break;
            case "requires_payment_method":
                showMessage("Your payment was not successful, please try again.");
                setReinit();
                break;
            default:
                showMessage("Something went wrong.");
                setReinit();
                break;
        }
    } else {
        showMessage("Something went wrong.");
        setReinit();
    }
}


// Display message
function showMessage(messageText) {
    const messageContainer = document.querySelector("#paymentResponse");
    
    messageContainer.classList.remove("hidden");
    messageContainer.textContent = messageText;
    
    setTimeout(function () {
        messageContainer.classList.add("hidden");
        messageText.textContent = "";
    }, 5000);
}

// Show a spinner on payment submission
function setLoading(isLoading) {
    if (isLoading) {
        // Disable the button and show a spinner
        document.querySelector("#submitBtn").disabled = true;
        document.querySelector("#spinner").classList.remove("hidden");
        document.querySelector("#buttonText").classList.add("hidden");
    } else {
        // Enable the button and hide spinner
        document.querySelector("#submitBtn").disabled = false;
        document.querySelector("#spinner").classList.add("hidden");
        document.querySelector("#buttonText").classList.remove("hidden");
    }
}

// Show a spinner on payment form processing
function setProcessing(isProcessing) {
    if (isProcessing) {
        msform.classList.add("hidden");
        document.querySelector("#frmProcess").classList.remove("hidden");
    } else {
        msform.classList.remove("hidden");
        document.querySelector("#frmProcess").classList.add("hidden");
    }
}

// Show payment re-initiate button
function setReinit() {
    document.querySelector("#frmProcess").classList.add("hidden");
    document.querySelector("#payReinit").classList.remove("hidden");
}
</script>

';
 
$jsonStr = file_get_contents('php://input'); 
$jsonObj = json_decode($jsonStr); 

print_r($jsonObj);



//checking form data     

if(isset($_POST['submit'])){
    if(is_user_logged_in()){ 
        /*
        * insert data and create Appointments
        */  
        $user_id = get_current_user_id(); 
         $user_info = get_user_meta($user_id);

        $title = '';
        if($user_info['first_name'][0]){
            $title .= $user_info['first_name'][0];
        }else{
            $title .= $user_info['billing_email'][0];
        }
  
        $post_id = wp_insert_post(array (
            'post_type' => 'book_appointment',
            'post_title' => "User ".$title." Book Appointments", 
            'post_status' => 'publish',
            'comment_status' => 'closed',
            'ping_status' => 'closed',    
        ));
 
        /*
        *insert acf value
        */   
           
             /* * *
             *step I Fields 
             * * */
            //Group data
            $step_i_title = $step_i['title_setp_i']; 
            //Update the field using this array as value:
            update_field( 'step_i_title', $step_i_title, $post_id );   
 
              $step_i_r_f = $_POST['val_s_i']; // first repeater values price 
              $step_i_r_f_h_v = $_POST['checkbox_val_s_i']; // first repeater hidden values title  
                 $n1 = count($step_i_r_f);
                for ($i=0; $i < $n1; $i++) { 

                    $row[] = array(
                        'title_step_i_r_title' => $step_i_r_f_h_v[$i],  
                        'step_i_r_price' => $step_i_r_f[$i]
                ); 
                $newrow = $row;
            }
            update_field( 'step_i_select_services', $newrow ,$post_id);  
             
             /* * *
             *step II Fields   
             * * */

             //Gender Update 
            $val_step_gender = $_POST['gender']; // step II gender select
            if(isset($val_step_gender)){
                $g_data = array( 'user_gender'	=>	$val_step_gender);  
                 update_field( 'step_ii_users_gender', $g_data, $post_id );
            }

           //Repeater data update
           $val_step2 = $_POST['checkbox_val_s_ii']; // repeater step 2
            if(isset($val_step2)){  

            $n2 = count( $val_step2);
                    for ($i2=0; $i2 < $n2; $i2++) { 

                        $row2[] = array(
                            'step_ii_r_price' => $val_step2[$i2]
                    ); 
                    $newrow2 = $row2;
                } 
        }
            update_field( 'step_ii_select_services', $newrow2 , $post_id);  
             

             /* * *
             *step III Fields   
             * * */

           //Repeater data update
           $val_step3 = $_POST['checkbox_val_s_iii']; // repeater step 2
           if(isset($val_step3)){  

           $n3 = count( $val_step3);
                   for ($i3=0; $i3 < $n3; $i3++) { 

                       $row3[] = array( 'step_iii_r_price' => $val_step3[$i3] ); 
                   $newrow3 = $row3;
               } 
       }
           update_field( 'step_iii_select_services', $newrow3 , $post_id);  


            /* * *
             *step IV Fields   
             * * */ 

                // update user_meta if not exist values


                $first_name_v =   $_POST['first_name'];
                if(isset($first_name_v )){ 
                    update_user_meta( $user_id, 'first_name', $first_name_v );
                }
            $last_name_v =   $_POST['last_name']; 
                if(isset($last_name_v )){ 
                    update_user_meta( $user_id, 'last_name', $last_name_v );
                }
            $billing_city_v =   $_POST['billing_city'];
                if(isset($billing_city_v )){ 
                    update_user_meta( $user_id, 'billing_city', $billing_city_v );
                }
            $billing_country_v =   $_POST['billing_country'];
                if(isset($billing_country_v )){ 
                    update_user_meta( $user_id, 'billing_country', $billing_country_v );
                }
            $billing_email_v =   $_POST['billing_email'];
                if(isset($billing_email_v )){ 
                    update_user_meta( $user_id, 'billing_email', $billing_email_v );
                }
            $billing_phone_v =   $_POST['billing_phone'];
                if(isset($billing_phone_v )){ 
                    update_user_meta( $user_id, 'billing_email', $billing_phone_v );
                }
            $billing_postcode_v =   $_POST['billing_postcode'];
                if(isset($billing_postcode_v )){ 
                    update_user_meta( $user_id, 'billing_postcode', $billing_postcode_v );
                }

                $user_val = array(
                'first_name'   => $first_name_v,
                'last_name'   => $last_name_v,
                'city'   => $billing_city_v,
                'country'   => $billing_country_v,
                'email'   => $billing_email_v,
                'phone'   => $billing_phone_v,
                'zip_code'   => $billing_postcode_v 
                ); 
            update_field( 'step_iv_users', $user_val, $post_id );

            

            $service_name = $term->name;
            update_field( 'service_name', $service_name, $post_id );
            if(isset($_POST['first_name'])){
                update_field( 'first_name', $_POST['first_name'], $post_id ); 
            }

            /* * *
             *step Time Select Fields   
             * * */ 
            if(isset($_POST['step_v_repeater_val_time'])){
                $time = $_POST['step_v_repeater_val_time'];
                update_field( 'step_v_user_time', $time, $post_id ); 
            }


  
             /* * *
             *step V Fields   
             * * */ 
             //Service Persons Details  

             $p_service_person_name = $_POST['service_person']; 
             $p_persons_image = $_POST['persons_image']; // Image ID
             $p_persons_rating = $_POST['persons_rating'];
             $p_persons_gender = $_POST['persons_gender'];
        
              
              update_field('persons_image', $attachment_id, $post_id);
  
             //Group your data into an array:
                $p_values = array(
                    
                    'name'	=>	$p_service_person_name,
                    'field_63ca3e2eb3347'	=>	$p_persons_image, 
                    'persons_gender'	=>	$p_persons_gender,
                    'ratings'		=>	$p_persons_rating
                    
                ); 
                //Update the field using this array as value:
                update_field( 'service_persons_details', $p_values, $post_id );
  

             /* * *
             *step V Fields   
             * * */ 
             //Service Persons Details  




             





    }else{
        $register_url =  $site_url.'/index.php/register/'; 
        return  wp_redirect( $register_url );
    }
  
}

 
 

    return $html;
 
}

  




function udpate_address()
{

    if( ! isset( $_POST ) || empty( $_POST ) || ! is_user_logged_in() ) {
 
        $user_id  = get_current_user_id();    

        $first_name_val  = sanitize_text_field( $_POST['first_name'] );
        if(isset( $first_name_val)){
            update_user_meta( $user_id, 'first_name', $first_name_val );            
        } 

        $last_name_val   = sanitize_text_field( $_POST['last_name'] );
        if(isset( $last_name_val)){
            update_user_meta( $user_id, 'last_name', $first_name_val );            
        }     

        $billing_city_val   = sanitize_text_field( $_POST['billing_city'] ); 
        if(isset( $billing_city_val)){
            update_user_meta( $user_id, 'billing_city', $billing_city_val );            
        }  

        $billing_country_val   = sanitize_text_field( $_POST['billing_country'] );  
        if(isset( $billing_country_val)){
            update_user_meta( $user_id, 'billing_city', $billing_country_val );            
        }    

        $billing_phone_val   = sanitize_text_field( $_POST['billing_phone'] ); 
        if(isset( $billing_phone_val)){
            update_user_meta( $user_id, 'billing_phone', $billing_phone_val );            
        }   

        $billing_postcode_val   = sanitize_text_field( $_POST['billing_postcode'] );  
        if(isset( $billing_postcode_val)){
            update_user_meta( $user_id, 'billing_postcode', $billing_postcode_val );            
        }      
    
       
        /*  wp_update_user( array(
            'ID'            => $user_id,
            'user_email'    => $um_user_email,
            'billing_postcode' => $billing_postcode_val
        ) ); */
    
        //exit;
    }
  

}
add_action( 'wp_ajax_nopriv_udpate_address', 'udpate_address' );
add_action( 'wp_ajax_udpate_address', 'udpate_address' );
