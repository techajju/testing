<?php

add_shortcode('EnterPostalCode', 'enterPostalCode');

//error_reporting(E_ERROR | E_PARSE);

function enterPostalCode()
{
 
 
$site_url = get_site_url();  
    $code= '';
     $service =  $_GET['service'];
    if(empty($service)){
        echo "<h2>Please Select Any Service</h2>";
        exit();
    }

    ?>
    <link rel="stylesheet" href="http://s778608864.onlinehome.us/danugur/wp-content/plugins/woo-product-slider/src/Frontend/assets/css/font-awesome.min.css?ver=2.6.4">
    <?php
    //fist we check there which location user choose
    $code .= '<div class="postal_code_row"> 
    
                <div class="postal_code_col"> 
                  <div class="inr_postcde"> 
                   <span class="location_icon"><i class="fa fa-map-marker" aria-hidden="true"></i> </span>
                    <input type="text" placeholder="Enter your postcode" id="postalcode">
                   </div>
                    <input type="hidden" id ="siteurl" value='.$site_url.'>
                    <input type="hidden" id ="service" value='.$service.'>
                    <button id="postalcode_submit" OnClick="check_postal()">Continue</button> <br>
                    <span style="color: red;" id="error"></sapn>
                </div> 
            </div>'; 

     $place_id = 'ChIJdd4hrwug2EcRmSrV3Vo6llI'; //London Place Id 
    //$code .= '<script src="https://maps.googleapis.com/maps/api/js?v=3.exp&types=(cities)&libraries=places&key=AIzaSyBFaMaZy2Q7q1WqThHJDTeaRMOlcTkNxws"></script>';
     $code .= '  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBFaMaZy2Q7q1WqThHJDTeaRMOlcTkNxws"></script>  ';
    $code .= "<script>   
 
    postal_code = document.getElementById('postalcode'); 
    siteurl = document.getElementById('siteurl'); 
    services = document.getElementById('service'); 
    var geocoder = new google.maps.Geocoder(); 

    function check_postal() {
        var postal = postal_code.value;  
        // var postcode_regex = /[A-Z]{1,2}[0-9][0-9A-Z]?\s?[0-9][A-Z]{2}/g;
        var postcode_regex = /^(GIR[ ]?0AA|((AB|AL|B|BA|BB|BD|BH|BL|BN|BR|BS|BT|CA|CB|CF|CH|CM|CO|CR|CT|CV|CW|DA|DD|DE|DG|DH|DL|DN|DT|DY|E|EC|EH|EN|EX|FK|FY|G|GL|GY|GU|HA|HD|HG|HP|HR|HS|HU|HX|IG|IM|IP|IV|JE|KA|KT|KW|KY|L|LA|LD|LE|LL|LN|LS|LU|M|ME|MK|ML|N|NE|NG|NN|NP|NR|NW|OL|OX|PA|PE|PH|PL|PO|PR|RG|RH|RM|S|SA|SE|SG|SK|SL|SM|SN|SO|SP|SR|SS|ST|SW|SY|TA|TD|TF|TN|TQ|TR|TS|TW|UB|W|WA|WC|WD|WF|WN|WR|WS|WV|YO|ZE)(\d[\dA-Z]?[ ]?\d[ABD-HJLN-UW-Z]{2}))|BFPO[ ]?\d{1,4})$/;
          
        var postcodes = postal.match(postcode_regex);
    
        if(postcodes == null){
          alert('Please Enter Valid Postal Code');
          return;
        }
       // console.log(postcodes[0])
        geocoder.geocode({
          componentRestrictions: {
            country: 'UK',
            postalCode: postcodes[0]
          }
        }, function(results, status) { 
           //console.log(results[0].address_components[2].short_name); // cehck country is london
           var country = results[0].address_components[2].short_name;
           if(country == 'London'){  
                 window.location.href = siteurl.value+'/index.php/services?service='+services.value+'&postal='+postal; 
            }else{
            var errors = 'Please Enter Valid Postal Code';
             document.getElementById('error').innerHTML = errors;
           }
          
        });
        } 
    </script>";
  



   
return $code;
}

