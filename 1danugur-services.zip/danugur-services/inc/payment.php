<?php

// Include configuration file  
// / require_once MY_PLUGIN_PATH . 'inc/payment_init.php';
 // / include( plugin_dir_path( __DIR__ ) . 'stripe-php/init.php');

?>

<?php


add_shortcode( "StripePay", 'PayWithStripeFormDanguar' );
/* define('STRIPE_API_KEY', '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'); 
define('STRIPE_PUBLISHABLE_KEY', 'pk_live_51IbgI6SEyJO7ICxpchzkfcXntBezxTQJwAqD65SgpMwdOsr7dZpbmyiDuNzf3PDL6RxPHn4kTf3LdLU2F0TMRDsl00uV39coSm'); 
   */
function PayWithStripeFormDanguar($atts,$itemPrice=0, $itemName="", $currency="")
{

    shortcode_atts(array(
        'itemPrice' => $itemPrice,
        'itemName' => $itemName,
        'currency' => $currency
    ), $atts);



    $site_url = get_site_url();
    $STRIPE_PUBLISHABLE_KEY = "pk_live_51IbgI6SEyJO7ICxpchzkfcXntBezxTQJwAqD65SgpMwdOsr7dZpbmyiDuNzf3PDL6RxPHn4kTf3LdLU2F0TMRDsl00uV39coSm";
    $STRIPE_API_KEY = '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';
   
    $code = '';
    $code = '
    <!-- Stripe JS library -->
     
    <div class="panel">
        <div class="panel-heading">
            <h3 class="panel-title">Charge $'.$itemPrice.' with Stripe</h3>
            
            <!-- Product Info -->
            <p><b>Item Name:</b> '. $itemName.'</p>
            <p><b>Price:</b> '. '$'.$itemPrice.' '.$currency.'</p>
        </div>
        <div class="panel-body">
            <!-- Display status message -->
            <div id="paymentResponse" class="hidden"></div>
            
            <!-- Display a payment form -->
            <form id="paymentFrm" class="hidden">
                <div class="form-group">
                    <label>NAME</label>
                    <input type="text" id="name" class="field" placeholder="Enter name" required="" autofocus="">
                </div>
                <div class="form-group">
                    <label>EMAIL</label>
                    <input type="email" id="email" class="field" placeholder="Enter email" required="">
                </div>
                
                <div id="paymentElement">
                    <!--Stripe.js injects the Payment Element-->
                </div>
                
                <!-- Form submit button -->
                <button id="submitBtn" class="btn btn-success">
                    <div class="spinner hidden" id="spinner"></div>
                    <span id="buttonText">Pay Now</span>
                </button>
            </form>
            
            <!-- Display processing notification -->
            <div id="frmProcess" class="hidden">
                <span class="ring"></span> Processing...
            </div>
            
            <!-- Display re-initiate button -->
            <div id="payReinit" class="hidden">
                <button class="btn btn-primary" onClick="window.location.href=window.location.href.split("?")[0]"><i class="rload"></i>Re-initiate Payment</button>
            </div>
        </div>
    </div>
    
        ';

return $code;
}