<?php

// Select Service page shortcode

add_shortcode('SelectService', 'selectServices');


function selectServices()
{

    $code = '';

    $code .='<div class="select_services_row"> ';
 
    $cats = get_terms( 'services', array(
        'hide_empty' => false,
    ) ); 

    $code .= ' <div class="select_services_form">  
    <input id ="cat_options" list="cats">
    <datalist id="cats">'; 
        foreach ($cats as $key => $cat) { 
           $code .= ' <option id="option-'.$cat->term_id.'"  data-id="'.$cat->slug.'" value="'.$cat->name.'"></option>'; 
            $code .= '<script>
            jQuery("#cat_options").on("input", function () {  
               var val = document.getElementById(`option-'.$cat->term_id.'`).getAttribute("data-id");  
                if(jQuery("#cats option").filter(function(){
                    return val;        
                }).length) { 
                    window.location.href = "'.get_site_url().'/index.php/enter-postcode?service="+val;

                 }
            }); 
            </script>';
        }  
     $code .= ' </datalist>   
            </div> 
                <div class="select_services_cat"> 
                <ul> ';
        foreach ($cats as $key => $cat) {
     
           $code .= '<li class="list-'.$cat->term_id.'"><a href="'.get_site_url().'/index.php/enter-postcode?service='.$cat->slug.'">'.$cat->name.'</a></li>'; 
         }   
            
        $code .='</ul> 
    </div> 
</div>';

$code .= '</div>';

return $code;
 
} 





